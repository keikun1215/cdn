import time
import websocket
import json
import threading
import random
import string
import requests
from colorama import Back, Fore

spamflag = False

with open("config.json") as f:
    config = json.load(f)
    f.close()
channels = []
members = []


def randalpha(n): return "".join(random.choices(string.ascii_letters, k=n))


def question(what, correct):
    answer = input(what)
    if answer not in correct:
        print("Invalid selection")
        return question(what, correct)
    else:
        return answer


def header(token):
    return {"Content-Type": "Application/json", "Authorization": token}


def randoment(amount):
    return " ".join(map(lambda x: f"<@{x}>", random.sample(members, amount)))


def createMessage(str: str):
    global members
    filter0 = str.replace(
        "{randomM}",
        randoment(
            len(members) if config["random_mention_amount"] > len(members) else
            config["random_mention_amount"]))
    filter1 = filter0
    for _ in range(filter0.count("{randomA}")):
        filter1 = filter1.replace("{randomA}", randalpha(
            config["random_alphabet_amount"]), 1)
    return filter1


def spam():
    global spamflag
    spamflag = True
    r = open("data.json", mode="r")
    dat = json.load(r)
    r.close()
    if len(config["channels"]) == 0:
        channels = dat["guilds"][config["guild"]]["channels"]
    else:
        channels = config["channels"]
    msgraw = open("message.txt", encoding="utf-8").read()
    while spamflag:
        for token in config["tokens"]:
            message = createMessage(msgraw)
            chid = random.choice(channels)
            requests.post(
                f"https://discord.com/api/v10/channels/{chid}/messages",
                json={"content": message[:2000]},
                headers=header(token))
        time.sleep(config["interval"])


def handle():
    input("press enter to stop")
    spammer()


def spammer():
    global spamflag
    spamflag = False
    select = question(
        """
░█████╗░██╗███╗░░░███╗██╗░░░██╗██████╗░
██╔══██╗██║████╗░████║██║░░░██║██╔══██╗
███████║██║██╔████╔██║██║░░░██║██████╔╝
██╔══██║██║██║╚██╔╝██║██║░░░██║██╔══██╗
██║░░██║██║██║░╚═╝░██║╚██████╔╝██║░░██║
╚═╝░░╚═╝╚═╝╚═╝░░░░░╚═╝░╚═════╝░╚═╝░░╚═╝

[1]: Spammer
[2]: Leave
[3]: Exit

> """, ["1", "2", "3"])
    if select == "1":
        thread_1 = threading.Thread(target=spam)
        thread_2 = threading.Thread(target=handle)
        thread_1.start()
        thread_2.start()
    elif select == "2":
        for token in config["tokens"]:
            requests.delete("https://discord.com/api/v10/users/@me/guilds/" +
                            config["guild"],
                            headers=header(token))


def suc(str):
    print(Back.LIGHTGREEN_EX + Fore.MAGENTA + "[+]" + Back.RESET + Fore.RESET +
          " " + str)


def fld(str):
    print(Back.LIGHTRED_EX + Fore.BLUE + "[+]" + Back.RESET + Fore.RESET + " " +
          str)


def main():
    global members
    r = open("data.json", mode="r")
    dat = json.load(r)
    r.close()
    if config["guild"] not in dat["guilds"]:
        wsapp = websocket.WebSocketApp(
            "wss://gateway.discord.gg/?v=10&encoding=json",
            header={
                "Accept-Encoding":
                "gzip, deflate, br",
                "Accept-Language":
                "en-US,en;q=0.9",
                "Cache-Control":
                "no-cache",
                "Pragma":
                "no-cache",
                "Sec-WebSocket-Extensions":
                "permessage-deflate; client_max_window_bits",
                "User-Agent":
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_6 rv:3.0; sl-SI) AppleWebKit/535.47.1 (KHTML, like Gecko) Version/4.0 Safari/535.47.1"
            },
            on_open=on_open,
            on_message=on_message)
        wsapp.run_forever()
    else:
        suc("Websocket didn't required!")
        members = dat["guilds"][config["guild"]]["members"]
        spammer()


def on_message(ws: websocket.WebSocketApp, message: bytes):
    msg = json.loads(message)
    r = open("data.json", mode="r")
    dat = json.load(r)
    r.close()
    if msg["op"] == 0:
        if msg["t"] == "READY":
            if config["guild"] not in dat["guilds"]:
                dat["guilds"][config["guild"]] = {
                    "members": [], "channels": []}
                chsraw = requests.get("https://discord.com/api/v10/guilds/" +
                                      config["guild"] + "/channels",
                                      headers=header(config["tokens"][0]))
                chs = list(
                    map(lambda c: c["id"],
                        list(filter(lambda c: c["type"] == 0, chsraw.json()))))
                if code := chsraw.status_code == 200:
                    suc("Succesfuly scraped channels!")
                    dat["guilds"][config["guild"]]["channels"] = chs
                else:
                    fld(f"Failed to scrape channels. code: {code}")
                    dat["guilds"][config["guild"]]["channels"] = []
                ws.send(
                    json.dumps({
                        "op": 14,
                        "d": {
                            "guild_id": config["guild"],
                            "channels": {chs[0]: [[0, 99]]}
                        }
                    }))
                suc("Members request said!")
                with open("data.json", mode='w') as w:
                    json.dump(dat, w)
                    w.close()
            else:
                members.extend(dat["guilds"][config["guild"]]["members"])
                suc("Guild members restored!")
                ws.close()
                suc("Disconnected from Discord!")
                spammer()
        if msg["t"] == "GUILD_MEMBER_LIST_UPDATE":
            opo = msg["d"]["ops"][0]
            if opo["op"] == "SYNC":
                for item in opo["items"]:
                    if "member" in item:
                        members.append(item["member"]["user"]["id"])
                dat["guilds"][config["guild"]]["members"] = members
                with open("data.json", mode='w') as w:
                    json.dump(dat, w)
                    w.close()
                suc("Guild members saved!")
                ws.close()
                suc("Disconnected from Discord!")
                spammer()


def on_open(ws: websocket.WebSocketApp):
    suc("WebSocket connected!")
    ws.send(
        json.dumps({
            "d": {
                "token": config["tokens"][0],
                "capabilities": 4093,
                "properties": {
                    "os": "Mac OS X",
                    "browser": "Safari",
                    "device": "",
                    "browser_user_agent":
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_5_6 rv:3.0; sl-SI) AppleWebKit/535.47.1 (KHTML, like Gecko) Version/4.0 Safari/535.47.1",
                    "browser_version": "4.0",
                    "os_version": "10.5.6",
                    "referrer": "",
                    "referring_domain": "",
                    "referrer_current": "",
                    "referring_domain_current": "",
                    "release_channel": "stable",
                    "client_build_number": 117300,
                    "client_event_source": None
                },
                "presence": {
                    "status": "online",
                    "since": 0,
                    "activities": [],
                    "afk": False
                },
                "compress": False,
                "client_state": {
                    "guild_hashes": {},
                    "highest_last_message_id": "0",
                    "read_state_version": 0,
                    "user_guild_settings_version": -1,
                    "user_settings_version": -1
                }
            },
            "op": 2
        }))


main()
